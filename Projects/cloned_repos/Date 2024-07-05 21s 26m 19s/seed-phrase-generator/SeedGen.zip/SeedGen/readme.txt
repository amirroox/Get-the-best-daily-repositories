A Seed Phrase Generator is a tool designed to create a unique set of words that can be used to 
seed a cryptocurrency wallet, enabling users to securely store and access their digital assets. 
These seed phrases are typically made up of a sequence of 12 randomly generated words that act 
as a backup for the wallet.

This program can generate seed phrases, as well as search for wallets containing BTC, ETH, LTC, DOGE coins.
Compared to other generators written in python, this program is written in C++, which makes it many 
times faster than those.

But know that luck is key here.